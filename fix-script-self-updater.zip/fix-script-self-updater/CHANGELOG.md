# Changelog

All notable changes to this project will be documented in this file.

## [1.0.0] - 2025-09-11
### Added
- Initial import of `fix_script_self_updater.js` that syncs Fix Script name and description from variables.
- Auto-fingerprint on first run for self-identification across runs.
