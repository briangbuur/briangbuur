# Fix Script: Self-Updater (ServiceNow)

This repository contains a **ServiceNow Fix Script** that keeps its own record's **name** and **description** in sync with two variables in the script source.

- `SCRIPT_NAME` → copied to the Fix Script record's `name` (auto-truncated to 40 chars).
- `SCRIPT_DESCRIPTION` → copied to the Fix Script record's `description`.
- On first run in a new environment, the script auto-generates and persists a fingerprint comment to uniquely find itself on subsequent runs.

## Files
- `src/fix_script_self_updater.js` — the script you paste into a _Fix Script_ record (`sys_script_fix.script`).
- `.gitignore` — standard JS/Node/OS ignores (you may trim as you like).
- `CHANGELOG.md` — optional; start tracking changes as you iterate (example entry included).

## How to Use in ServiceNow
1. Create a new **Fix Script** (`System Definition → Fix scripts → New`).
2. Paste the contents of `src/fix_script_self_updater.js` into the **Script** field.
3. Edit the two variables at the top:
   ```js
   var SCRIPT_NAME = "My Final and Correct Script Name v.1223";
   var SCRIPT_DESCRIPTION = "This text will be copied into the 'description' field of the Fix Script record.";
   ```
4. Click **Run Fix Script**.
   - First run in a new environment: a fingerprint line is appended to the end of the script (`// SELF_FINGERPRINT: <guid>`).
   - Subsequent runs: the script finds itself via that fingerprint and updates the record if needed.

## Notes
- `sys_script_fix.name` has a max of **40 characters**; the script truncates automatically.
- If you duplicate the script in the same instance *before the first run*, the fallback search may become ambiguous. Run once to persist the fingerprint, then duplicate if you must.

## GitHub: Create a New Repository (Web UI)
1. Go to GitHub → **New repository**.
2. Choose **Private** or **Public**, set a name (e.g., `servicenow-fix-script-self-updater`), and click **Create**.
3. Click **Add file → Upload files**, then drag the three files from this repo (`src/...`, `.gitignore`, `CHANGELOG.md`) or upload the provided ZIP.
4. Commit to `main` with a message like: `feat: initial import of self-updating fix script`.

## Git: Command Line (Alternative)
```bash
# 1) Create local repo
mkdir servicenow-fix-script-self-updater
cd servicenow-fix-script-self-updater
git init

# 2) Copy files into this folder (or unzip the provided archive)
#    Ensure the src/fix_script_self_updater.js is present

# 3) Commit
git add .
git commit -m "feat: initial import of self-updating fix script"

# 4) Create remote on GitHub (replace <you> and repo name)
git branch -M main
git remote add origin git@github.com:<you>/servicenow-fix-script-self-updater.git
git push -u origin main
```

## Next Steps
- Add a `LICENSE` of your choice (MIT is common).
- Consider a `README` section with your internal naming/versioning rules.
- If this script evolves, record changes in `CHANGELOG.md`.
