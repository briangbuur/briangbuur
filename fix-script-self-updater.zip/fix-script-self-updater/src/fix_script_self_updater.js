(function() {
    // ===== Edit only these two =====
    var SCRIPT_NAME = "My Final and Correct Script Name v.1223";
    var SCRIPT_DESCRIPTION = "This text will be copied into the 'description' field of the Fix Script record.";
    // =================================

    var NAME_MAX = 40; // sys_script_fix.name max length
    var FPLABEL = "SELF_FINGERPRINT:"; // persisted as a single-line comment in the script

    function _truncateName(s) {
        return (s && s.length > NAME_MAX) ? s.substring(0, NAME_MAX) : s;
    }

    function _findSelfByFingerprint() {
        var gr = new GlideRecord('sys_script_fix');
        gr.addQuery('script', 'CONTAINS', FPLABEL);
        gr.setLimit(10);
        gr.query();
        var results = [];
        while (gr.next()) results.push(gr.sys_id.toString());
        if (results.length === 1) {
            var g = new GlideRecord('sys_script_fix');
            g.get(results[0]);
            return g;
        }
        return null;
    }

    function _findSelfFallback(desiredName) {
        var gr = new GlideRecord('sys_script_fix');
        gr.addQuery('name', _truncateName(desiredName));
        gr.addQuery('script', 'CONTAINS', 'var SCRIPT_NAME =');
        gr.orderByDesc('sys_updated_on');
        gr.setLimit(3);
        gr.query();
        if (gr.next()) return gr;

        var gr2 = new GlideRecord('sys_script_fix');
        gr2.addQuery('script', 'CONTAINS', 'var SCRIPT_NAME =');
        gr2.orderByDesc('sys_updated_on');
        gr2.setLimit(1);
        gr2.query();
        if (gr2.next()) return gr2;

        return null;
    }

    function _ensureFingerprintPersisted(selfGr) {
        var body = selfGr.getValue('script') || "";
        if (body.indexOf(FPLABEL) !== -1) {
            return true;
        }
        var fp = gs.generateGUID();
        var suffix = "\n// " + FPLABEL + " " + fp + "\n";
        selfGr.setValue('script', body + suffix);
        selfGr.update();
        gs.info("Fix Script: generated and persisted new fingerprint: " + fp);
        return true;
    }

    try {
        var selfGr = _findSelfByFingerprint();
        if (!selfGr) {
            selfGr = _findSelfFallback(SCRIPT_NAME);
        }

        if (!selfGr) {
            gs.warn("Fix Script: could not uniquely identify the executing script record. Aborting.");
            return;
        }

        _ensureFingerprintPersisted(selfGr);

        var desiredName = _truncateName(SCRIPT_NAME);
        var currName = selfGr.getValue('name') || "";
        var currDesc = selfGr.getValue('description') || "";

        var needsUpdate = false;
        if (currName !== desiredName) {
            selfGr.setValue('name', desiredName);
            needsUpdate = true;
        }
        if (currDesc !== SCRIPT_DESCRIPTION) {
            selfGr.setValue('description', SCRIPT_DESCRIPTION);  // <-- copy description variable here
            needsUpdate = true;
        }

        if (needsUpdate) {
            selfGr.update();
            gs.info('Fix Script: record updated. name="' + desiredName + '", description updated.');
        } else {
            gs.info('Fix Script: record already in desired state.');
        }
    } catch (e) {
        gs.error("Fix Script error: " + e.message);
    }
})();
